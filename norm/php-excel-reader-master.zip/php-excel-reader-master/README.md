PHPExcelReader/SpreadsheetReader
================================

This is the Spreadsheet_Excel_Reader class from http://code.google.com/p/php-excel-reader/.
This PHP library expands on the great work done in the PHP Excel Reader project on SourceForge.
+ Some patches to make it work with newer PHP versions

It reads the binary format of XLS files directly and can return values and formats from any cell.

This version changed the class name and location to match the psr-0 namespacing standard,
and added a composer.json file to make it installable via composer (packagist.org).

For License and Authors look at the composer.json file and the top comment in the class file.
